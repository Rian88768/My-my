import acrcloud from 'acrcloud'
import ytdl from 'ytdl-core'
import fs from 'fs'
import ffmpeg from 'fluent-ffmpeg'
import search from 'yt-search'

let acr = new acrcloud({
    host: 'identify-eu-west-1.acrcloud.com',
    access_key: '1561a11eab4ab229f323cac3bab2909f',
    access_secret: '4XYoTSkwC8OvSRXVCrjDZAqpqT1oLnvsoDpLodxg'
})

let handler = async (m, { conn, usedPrefix, command }) => {
    let q = m.quoted ? m.quoted : m
    let mime = (q.msg || q).mimetype || q.mediaType || ''
    if (/video|audio/.test(mime)) {
        let buffer = await q.download()
        await m.reply('_In progress, please wait..._')
        let { status, metadata } = await acr.identify(buffer)
        if (status.code !== 0) throw status.msg
        let { title, artists, album, genres, release_date } = metadata.music[0]
        let txt = `*• Title:* ${title}${artists ? `\n*• Artists:* ${artists.map(v => v.name).join(', ')}` : ''}`
        txt += `${album ? `\n*• Album:* ${album.name}` : ''}${genres ? `\n*• Genres:* ${genres.map(v => v.name).join(', ')}` : ''}\n`
        txt += `*• Release Date:* ${release_date}`
        
        // Send information message
        await conn.sendMessage(m.chat, {
            text: `${txt.trim()}\n\n*• File music sedang dikirim silahkan tunggu* `,
        }, { quoted: m });

        // Search for the song on YouTube
        let searchResults = await search(title)
        let video = searchResults.videos[0]
        if (!video) throw 'No video found'

        // Download the song from YouTube
        let stream = ytdl(video.url, { filter: 'audioonly' })
        let filePath = `./tmp/${title}.mp3`

        ffmpeg(stream)
            .audioBitrate(128)
            .save(filePath)
            .on('end', async () => {
                // Send the downloaded file to the user
                await conn.sendMessage(m.chat, { audio: fs.readFileSync(filePath), mimetype: 'audio/mp4' }, { quoted: m })
                // Delete the temporary file
                fs.unlinkSync(filePath)
            })
            .on('error', err => {
                console.error(err)
                throw 'Error downloading the song'
            })

    } else throw `Reply audio/video with command ${usedPrefix + command}`
}
handler.help = handler.alias = ['whatmusic']
handler.tags = ['tools']
handler.command = /^(whatmusic)$/i
handler.register = false
handler.diamond = true

export default handler