
import fetch from 'node-fetch';
export async function before(m, { conn }) {
   let pp = await this.profilePictureUrl(m.sender, 'image').catch(_ => 'https://i.imgur.com/whjlJSf.jpg');

  // Respuesta con enlace de WhatsApp
  global.rpl = {
    contextInfo: {
      externalAdReply: {
        mediaUrl: NSgc,
        mediaType: 'VIDEO',
        description: 'support group',
        title: packname,
        body: 'grupo de soporte',
        thumbnailUrl: pp,
        sourceUrl: NSgc
      }
    }
  };

  // Respuesta con enlace de PayPal
  global.rpyp = {
    contextInfo: {
      externalAdReply: {
        mediaUrl: NSgc,
        mediaType: 'VIDEO',
        description: 'Donate',
        title: 'PayPal',
        body: 'membantu menjaga bot tetap aktif',
        thumbnailUrl: pp,
        sourceUrl: NSgc
      }
    }
  };

  // Respuesta con enlace de Instagram
  global.rpig = {
    contextInfo: {
      externalAdReply: {
        mediaUrl: NSig,
        mediaType: 'VIDEO',
        description: 'Ikuti saya di Instagram',
        title: 'Instagram',
        body: 'ikuti saya di Instagram ',
        thumbnailUrl: pp,
        sourceUrl: NSig
      }
    }
  };

  // Respuesta con enlace de YouTube
  global.rpyt = {
    contextInfo: {
      externalAdReply: {
        showAdAttribution: true,
        mediaUrl: NSgc,
        mediaType: 'VIDEO',
        description: 'Subscribe: ' + NSgc,
        title: 'FG YouTube',
        body: 'belajar membuat bot Anda sendiri',
        thumbnailUrl: pp,
        sourceUrl: NSgc
      }
    }
  }
  
  
  
}
