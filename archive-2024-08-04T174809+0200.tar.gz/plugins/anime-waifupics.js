import fetch from 'node-fetch'

let handler = async (m, { conn, args, usedPrefix, command }) => {
  m.react(rwait)

  let type = (command).toLowerCase()

  switch (type) {
    case 'waifu1':
    case 'megumin':
      let res = await fetch(`https://api.waifu.pics/sfw/${type}`)
      if (!res.ok) throw await res.text()
      let json = await res.json()
      if (!json.url) throw '❎ Error'
      conn.sendFile(m.chat, json.url, 'img.jpg', `✅ Random ${type}`, m)
      m.react(dmoji)
      break

    default:
      throw '❎ Command not found'
  }
}

handler.help = ['waifu1', 'megumin']
handler.tags = ['anime']
handler.command = ['waifu1', 'megumin']
handler.diamond = true

export default handler

function pickRandom(list) {
  return list[Math.floor(list.length * Math.random())]
}